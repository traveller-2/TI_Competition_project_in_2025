#ifndef _MOTOR_H
#define _MOTOR_H
#include "ti_msp_dl_config.h"
#include "board.h"
int Calculate_target(int Target);
void Set_PWM(int L_Target,int R_Target);
int Calculate_target(int Target) ;
#endif