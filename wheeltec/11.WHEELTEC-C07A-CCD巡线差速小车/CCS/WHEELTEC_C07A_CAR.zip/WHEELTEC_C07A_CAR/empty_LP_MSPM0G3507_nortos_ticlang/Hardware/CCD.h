#ifndef _CCD_H
#define _CCD_H
#include "board.h"
int adc_getValue(void);
extern uint8_t CCD_Zhongzhi;
extern uint16_t ADV[128];
extern unsigned int adc_value ;
extern unsigned int voltage_value;
extern volatile bool gCheckADC;        //ADC�ɼ��ɹ���־λ
void CCD_Mode(void);
extern float CCD_KP,CCD_KI,CCD_Vel;
void TSL_CLK(int state);  // 0=�͵�ƽ, 1=�ߵ�ƽ
void TSL_SI(int state);   // 0=�͵�ƽ, 1=�ߵ�ƽ
void RD_TSL(void);
void  Find_CCD_Median (void); 
#endif