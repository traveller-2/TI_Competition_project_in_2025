#ifndef __ADC_H__
#define __ADC_H__
#include "board.h"
float Get_battery_volt(void);
#endif
