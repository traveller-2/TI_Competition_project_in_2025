#ifndef __SHOW_H
#define __SHOW_H

#include "ti_msp_dl_config.h"
#include "balance.h"
#include "MPU6050.h"

void oled_show(void);

#endif