#ifndef _ENCODER_H
#define _ENCODER_H
#include "ti_msp_dl_config.h"

#endif
