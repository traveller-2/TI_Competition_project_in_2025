#ifndef _MAIN_H_
#define _MAIN_H_

#include "clock.h"

#include "mpu6050.h"

#endif  /* #ifndef _MAIN_H_ */